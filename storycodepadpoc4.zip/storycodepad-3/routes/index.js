var mongoose = require('mongoose')
mongoose.connect('mongodb://blackfox:naruto45@ds062448.mlab.com:62448/keytechlabs');
var Schema = mongoose.Schema;

var TopicDataSchema = new Schema({
  name: String,
  Def: String
}, {collection: 'Topic'});

var certDataSchema = new Schema({
  name: String,
  Def: String
}, {collection: 'certifications'});


var TopicData = mongoose.model('TopicData', TopicDataSchema);
var certData = mongoose.model('certData', certDataSchema);
module.exports = function(app, dbs) {

  app.get('/production', (req, res, next) => {
    TopicData.find()
      .then(function(tdoc) {
    certData.find()
      .then(function(cdoc) {
        res.render('index', {items: tdoc, cert: cdoc});

      });
      });
});




  return app
}