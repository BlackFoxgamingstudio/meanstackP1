module.exports = function(app, dbs) {

  app.get('/production', (req, res, next) => {
    dbs.production.collection('certifications').find({}).toArray((err, docs) => {
      if (err) {
        console.log(err)
        res.error(err)
      } else {
          var array = []; 

      for (var i = 0; i < docs.length; i++) {
        array.push(docs[i]);
       
    }

    
        var sarray = JSON.stringify(array);
        res.render('index', {items: sarray });
      }
    })
  })

  app.get('/marketing', (req, res, next) => {
    dbs.marketing.collection('Topic').find({}).toArray((err, docs) => {
      if (err) {
        console.log(err)
        res.error(err)
      } else {
        var array = []; 

        array.push(docs);
        var sarray = JSON.stringify(array);
        res.render('index', {items: sarray });
      }
    })
  })

  return app
}