var express = require('express');
var mongoose = require('mongoose');
var router = express.Router();
mongoose.connect('mongodb://blackfox:naruto45@ds062448.mlab.com:62448/keytechlabs');
var Schema = mongoose.Schema;

var TopicDataSchema = new Schema({
  certifucation_id: String
}, {collection: 'Topic'});

var certDataSchema = new Schema({
  name: String
}, {collection: 'certifications'});


var TopicData = mongoose.model('TopicData', TopicDataSchema);
var certData = mongoose.model('certData', certDataSchema);

  router.get('/production/certifucation/:name/topic/:certifucation_id', (req, res, next) => {
   
   var certifucation_id = req.params.certifucation_id;
    certData.findOne({name: req.params.name})
    .then(function(cdoc){
    TopicData.findOne({certifucation_id})
    .then(function(tdoc) {

      res.render('index', {cert: JSON.stringify(cdoc), topic: JSON.stringify(tdoc)})

      });
      });
});


module.exports = router;
