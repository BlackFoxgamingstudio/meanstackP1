module.exports = function(app, dbs) {

  app.get('/production', (req, res, next) => {
    dbs.production.collection('certifications').find({}).toArray((err, docs) => {
      if (err) {
        console.log(err)
        res.error(err)
      } else {
          var array = []; 

      for (var i = 0; i < docs.length; i++) {
        array.push(docs[i]);
       
    }

    
        var sarray = JSON.stringify(array);
        res.render('index', {items: sarray });
      }
    })
  })

app.get('/production/:name', (req, res, next) => {
   var name = req.params.name;
    dbs.production.collection('certifications').find({name}).next(function(err, docs) {
      if (err) {
        console.log(err)
        res.error(err)
      } else {
       console.log(docs)
       var TOPIC = docs.num_of_topics;
       var TASK = docs.num_of_tasks;
       var DEF = docs.description;
       var ID = docs._id;

        //var sarray = JSON.stringify(docs);
       
          
           res.render('index', {name: name,id: ID, topic: TOPIC, task: TASK, def: DEF });
      }
    })
    
  })

  app.get('/marketing', (req, res, next) => {
    dbs.marketing.collection('Topic').find({}).toArray((err, docs) => {
      if (err) {
        console.log(err)
        res.error(err)
      } else {
        var array = []; 

        array.push(docs);
        var sarray = JSON.stringify(array);
        res.render('index', {items: sarray });
      }
    })
  })

  return app
}